#!/bin/sh
./miner --algo kawpow --server rvn.2miners.com:6060 --user RH2swPipTDBBNxEBdzWuNa4roBu6kFzoTz
