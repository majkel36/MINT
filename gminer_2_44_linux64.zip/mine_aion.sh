#!/bin/sh
./miner --algo 210_9 --pers AION0PoW --server eu.aionpool.tech:2222 --user 0xa0a34ed4cfba29588e7da4a05c530c5431746aafbaa5301a2e990557a45ea338 --pass x
