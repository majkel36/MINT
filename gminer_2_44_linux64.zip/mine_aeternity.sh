#!/bin/sh
./miner --algo aeternity --server ae.2miners.com:4040 --user ak_v4cBSQhjh8gc49XMmrt1ELXJDA8U7sDZVKhLJiAzjPymVFgFQ
