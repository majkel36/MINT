#!/bin/sh
./miner --algo vds --server vds.666pool.cn:9338 --user VcjzzkoRBxFfP3a5LWZXhfTeMF9sV53GkUL.rig0 --pass x
