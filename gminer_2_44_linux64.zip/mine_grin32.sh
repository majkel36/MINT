#!/bin/sh
./miner --algo grin32 --server grin.2miners.com:3030 --user 2aHR0cHM6Ly9ncmluLmdhdGVpby5saXZlL2RlcG9zaXQvZ2F0ZWlvZ3Jpbi8wMDI0ZDA0YjZjNmRmZWU5
