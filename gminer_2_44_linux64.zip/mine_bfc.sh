#!/bin/sh
./miner --algo bfc --server bfc.uupool.cn:12210 --user develsoftware
