#!/bin/sh
./miner --algo cuckaroo29b --server mining.bittube.app:3300 --user SbLe6pLBPBPXxnFtrzGSzJ2qcLPA9ZzomchJysk2LxsY1FGuJgnWBVR3rUmAhG865EQuLuBpNu5n82aBmEpqKqSX1aaMc1WJd
