#!/bin/sh
./miner --algo 192_7 --pers ZcashPoW --server eu1-ycash.flypool.org:3333 --user s1ZpDP65RjYqNpRRnP5DB9fSsUJEpQKJDNj --pass x
