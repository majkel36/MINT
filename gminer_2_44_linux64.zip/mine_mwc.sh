#!/bin/sh
./miner --algo cuckatoo31 --server mwc.2miners.com:1111 --user 2aHR0cHM6Ly9ncmlucHJveHkuYml0Zm9yZXguY29tLzE5ODkzMzA
